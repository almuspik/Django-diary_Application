from django.db import models
from django.contrib.auth.models import User

class DiaryEntry(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='diary_entries')  # Added related_name for convenience
    title = models.CharField(max_length=100)
    content = models.TextField()
    date_created = models.DateTimeField(auto_now_add=True)


    class Meta:
        ordering = ['-date_created']  # New: Orders entries by newest first

    def __str__(self):
        return f"{self.title} by {self.user.username}"

class Userprofile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')#It creates a one-to-one relationship, meaning each user has exactly one set of additional detail belong to only one user.
    dob = models.DateField()
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)

    def __str__(self):
        return f"profile of {self.user.username}"
