from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('entry/<int:entry_id>/', views.entry_detail, name='entry_detail'),
    path('create/', views.create_entry, name='create_entry'),
    path('update/<int:entry_id>/', views.update_entry, name='update_entry'),
    path('delete/<int:entry_id>/', views.delete_entry, name='delete_entry'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
]
