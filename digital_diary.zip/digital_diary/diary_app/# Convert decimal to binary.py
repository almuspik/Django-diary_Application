# Convert decimal to binary
def decimal_to_binary(decimal_number):
    if decimal_number == 0:
        return "0"
    
    binary = ""
    while decimal_number > 0:
        remainder = decimal_number % 2
        binary = str(remainder) + binary
        decimal_number //= 2
    return binary

# Example usage
decimal_number = int(input("Enter a decimal number: "))
print(f"Binary representation of {decimal_number} is {decimal_to_binary(decimal_number)}")
