from django.contrib import admin
from .models import DiaryEntry

# Register your models here.

admin.site.register(DiaryEntry)


