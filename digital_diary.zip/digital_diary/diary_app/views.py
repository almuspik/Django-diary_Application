from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import DiaryEntry
from .models import Userprofile
from .forms import DiaryEntryForm, SignUpForm
from django.db.models import Q

# Create your views here.

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save() 
            Userprofile.objects.create(
                user=user,
                phone=form.cleaned_data['phone_number'],
                email=form.cleaned_data['email'],
                dob=form.cleaned_data['date_of_birth']
            )
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'diary_app/signup.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('index')
    return render(request, 'diary_app/login.html')

def user_logout(request):
    logout(request)
    return redirect('login')

@login_required
def index(request):
    query = request.GET.get('q')  # Get search query from the URL
    if query:
        entries = DiaryEntry.objects.filter(
    Q(user=request.user) & (Q(title__icontains=query) | Q(date_created__icontains=query))
).order_by('-date_created')

        #entries = DiaryEntry.objects.filter(
        # Q(title__icontains=query) | Q(date_created__icontains=query)
        #).order_by('-date_created')
    else:
       entries = DiaryEntry.objects.filter(user=request.user).order_by('-date_created')
        # entries = DiaryEntry.objects.all().order_by('-date_created')

    return render(request, 'diary_app/index.html', {'entries': entries, 'query': query})
@login_required
def entry_detail(request, entry_id):
    entry = get_object_or_404(DiaryEntry, id=entry_id, user=request.user)
    return render(request, 'diary_app/entry_detail.html', {'entry': entry})

@login_required
def create_entry(request):
    if request.method == 'POST':
        form = DiaryEntryForm(request.POST)
        if form.is_valid():
            diary_entry = form.save(commit=False)
            diary_entry.user = request.user
            diary_entry.save()
            return redirect('index')
    else:
        form = DiaryEntryForm()
    return render(request, 'diary_app/create_entry.html', {'form': form})

@login_required
def update_entry(request, entry_id):
    entry = get_object_or_404(DiaryEntry, id=entry_id, user=request.user)
    if request.method == 'POST':
        form = DiaryEntryForm(request.POST, instance=entry)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = DiaryEntryForm(instance=entry)
    return render(request, 'diary_app/update_entry.html', {'form': form})

@login_required
def delete_entry(request, entry_id):
    entry = get_object_or_404(DiaryEntry, id=entry_id, user=request.user)
    if request.method == 'POST':
        entry.delete()
        return redirect('index')
    return render(request, 'diary_app/delete_entry.html', {'entry': entry})


